package com.company;
import java.util.HashMap;
import java.util.Map;

public class TipoDatosMain {
    public static void main(String[] args) {

        //PRIMITIVOS
        //Enteros
        byte numero0 = 1;
        short numero1 = 2;
        int numero2 = 3;
        long numero3 = 1000L;

        //Flotantes
        float numero4 = 10.5f;
        double numero5 = 100.5d;

        //Booleano
        boolean condicion = false;
        //Caracter
        char caracter = 'a';

        //NO PRIMITIVOS
        //Cadena de caracteres
        String nombre = "Rodol";
        //Envoltorios
        Byte numeros1 = null;
        Short numeros2 = null;
        Integer numeros3 = null;
        Long numeros4= null;
        Float numeros5 = null;
        Double numeros6 = null;
        Character caracter1 = null;

        //Array
        String[] array = new String[]{"Rodol", "Marcos", "Rocios"};
        //Listas
        String[] list = new String[]{"Rodol", "Marcos", "Rocios"};
        //Map
        Map<String, String> map = new HashMap<>();
        map.put("Nombre", "Rodol");

        //ESTRUCTURADOS
        //Clase
        Coche coche1 = new Coche("Honda");

    }
}

