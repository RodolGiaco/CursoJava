package com.company;

public class Coche {
    //Atributos
    String modelo;
    //Contructor
    public Coche(String modelo) {
        this.modelo = modelo;
    }
    @Override
    public String toString() {
        return "Coche{" +
                "modelo='" + modelo + '\'' +
                '}';
    }
}
