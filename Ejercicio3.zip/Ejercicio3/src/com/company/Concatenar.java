package com.company;

public class Concatenar {
    public static void main(String[] args) {

        String[] nombres = {"Rodol","Marcos","Rocio"};
        String todos = "";
        for(String nombre:nombres){
            todos += nombre + " ";
        }
        System.out.println(todos);

    }
}