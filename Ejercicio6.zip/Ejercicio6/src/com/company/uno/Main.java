package com.company.uno;

import java.io.*;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.Vector;

public class Main {
    public static void main(String[] args) {

        //Escribe el código que devuelva una cadena al revés.
        // Por ejemplo, la cadena "hola mundo", debe retornar "odnum aloh".
        String cadenaInvertida = reverse("Hola mundo");
        System.out.println(cadenaInvertida);

        // 1. Crea un array unidimensional de Strings y recórrelo,
        // mostrando únicamente sus valores.
        String[] numeros = new String[] { "1", "2", "3", "4", "5"};
        for (String numero: numeros) {
            System.out.println(numero);
        }

        // 2. Crea un array bidimensional de enteros y recórrelo,
        // mostrando la posición y el valor de cada elemento en ambas dimensiones.
        String[][] matriz = new String[2][4];
        matriz[0][0] = "1";
        matriz[0][1] = "2";
        matriz[0][2] = "3";
        matriz[0][3] = "4";

        matriz[1][0] = "1";
        matriz[1][1] = "2";
        matriz[1][2] = "3";
        matriz[1][3] = "4";


        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[1].length; j++) {
                System.out.println("Matriz["+i+"]"+"["+j+"]: "+matriz[1][j]);
            }
        }
        // 3. Crea un "Vector" del tipo de dato que prefieras, y añádele 5 elementos.
        // Elimina el 2o y 3er elemento y muestra el resultado final.
        Vector<String> vector = new Vector();
        vector.add("1");
        vector.add("2");
        vector.add("3");
        vector.add("4");
        vector.add("5");
        vector.remove("2");
        vector.remove("3");
        System.out.println(vector);
        // 4. Debido a que el vector es un array dinamico, cuando se supera la capacidad
        //espesificada se crea un nuevo array con el doble de capacidad y cuando se esta haciendo
        //la copia del anterior tenemos que se ocupa en memoria el equivalente a los 1000 datos del
        //primer array + el equivalente al doble que ocupan esto para el segundo array generado

        // 5. Crea un ArrayList de tipo String, con 4 elementos. Cópialo en una LinkedList.
        // Recorre ambos mostrando únicamente el valor de cada elemento.
        ArrayList<String> list = new ArrayList<>();
        list.add("A");
        list.add("B");
        list.add("C");
        list.add("D");
        System.out.println(list);
        LinkedList<String> linkedList = new LinkedList<>();

        for (Object ArrayListObject : new LinkedList(list)) {
            System.out.println(ArrayListObject.toString());
        }
        // 6. Crea un ArrayList de tipo int, y, utilizando un bucle rellénalo con elementos 1..10.
        // A continuación, con otro bucle, recórrelo y elimina los numeros pares. Por último, vuelve a
        // recorrerlo y muestra el ArrayList final. Si te atreves, puedes hacerlo en menos pasos, siempre
        // y cuando cumplas el primer "for" de relleno.
        ArrayList<Integer> list2 = new ArrayList<>();
        Integer cont = 0;
        for (int i = 1; i <11; i++) {
            if (i%2 != 0){
                list2.add(i);
            }
        }
        System.out.println(list2);
        // 7. Crea una función DividePorCero. Esta, debe generar una excepción ("throws")
        // a su llamante del tipo ArithmeticException que será capturada por su llamante
        // (desde "main", por ejemplo). Si se dispara la excepción, mostraremos el mensaje
        // "Esto no puede hacerse". Finalmente, mostraremos en cualquier caso: "Demo de código".

        try{
            System.out.println("La operacion da:"+dividePorCero(1,0));
        }catch (Exception e){
            System.out.println("No se puede hacer esa operacion");
        }finally {
            System.out.println("Finalizo");
        }
        // 8. Utilizando InputStream y PrintStream, crea una función que reciba dos parámetros:
        // "fileIn" y "fileOut". La tarea de la función será realizar la copia del fichero dado
        // en el parámetro "fileIn" al fichero dado en "fileOut".
        try {
            InputStream fileIn = new BufferedInputStream(new FileInputStream("C:/Users/rodol/IdeaProjects/Ejercicio6/src/com/company/uno/input"));
            PrintStream fileOut = new PrintStream("copia.txt");
            recibirFichero(fileIn, fileOut);


        }catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }


    }
    public static String reverse(String texto) {
        StringBuilder cadenaInvertida = new StringBuilder();
        int longitud = texto.length();
        for (int i = longitud-1; i >= 0; i--) {
            cadenaInvertida.append(texto.charAt(i));
        }
        return cadenaInvertida.toString();
    }
    public static int dividePorCero(int A, int B) throws ArithmeticException{
        int resultado = 0;
        try {
           resultado = A/B;
        }catch (ArithmeticException e) {
            throw new ArithmeticException();
        }
        return resultado;
    }
    public static void recibirFichero(InputStream fileIn, PrintStream fileOut) throws IOException {

        byte[] input = fileIn.readAllBytes();
        fileOut.write(input);

    }
}

