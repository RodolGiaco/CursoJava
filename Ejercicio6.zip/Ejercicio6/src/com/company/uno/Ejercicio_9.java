package com.company.uno;
import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;


public class Ejercicio_9 {
    /**
     * 9. Este ejercicio lee los datos de algunas personas dentro de un fichero llamado "ficheroPersonas"
     * y luego almacena cada una de esas personas en un HashMap donde las claves son : "Nombre","Edad","Pais"
     * y los valores son los extraidos del fichero que luego se copian en formato HashMap en otro fichero
     */
    public static void main(String[] args) {

        try {
            System.out.println("BIENVENIDOS AL REGISTRO DE PERSONAS");
            System.out.println("Puede cargar los datos en el ficheroPersonas");

            InputStream ficheroPersonas = new BufferedInputStream(new FileInputStream("src/com/company/uno/ficheroPersonas.txt"));
            PrintStream ficheroOutput = new PrintStream("ficheroCopiaSeguridad.txt");
            HashMap<String,String> persona = new HashMap<>();
            HashMap<String,String> aux = new HashMap<>();
            ArrayList<String> registro = new ArrayList<>();


            int dato = ficheroPersonas.read();
            int cont = 0;
            String datos = "";
            String tipoDato ="";
            while(dato != -1) {
                datos += (char)dato;
                dato = ficheroPersonas.read();

                if ((char)dato == ' ' || (char)dato == '\r' || datos.equals("\r\n" )){
                    cont++;
                    tipoDato =  switch (cont) {
                        case 1 -> "Nombre";
                        case 2 -> "Edad";
                        case 3 -> "Pais";
                        default -> "";
                    };
                    if (datos.equals("\r\n" )){
                        String hashMapString = persona.toString();
                        registro.add(hashMapString);
                        cont = 0;
                        datos = "";
                    }else{
                        persona.put(tipoDato, datos); //Si subo algo con la misma clave se remplaza
                        datos = "";
                    }
                }
            }
            for(String datosFichero: registro) {
                System.out.println(datosFichero);
                ficheroOutput.println(datosFichero);
            }
        }catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}

