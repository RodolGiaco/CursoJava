public class Funciones {
    public static void main(String[] args) {

        double precio = 1000.5d;
        double newPrecio = getPrecioIva(precio);
        System.out.println("El precio con el IVA incluido es:"+newPrecio);
    }

    static double getPrecioIva(double precio) {
        double precioIva = precio - precio*0.21;
        return precioIva;
    }
}