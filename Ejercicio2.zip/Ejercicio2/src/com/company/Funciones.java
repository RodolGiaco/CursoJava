package com.company;
import java.util.Scanner;

public class Funciones {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        System.out.println("Introduce el precio: ");
        double precio = teclado.nextDouble();
        double newPrecio = getPrecioIva(precio);
        System.out.println("El precio con el IVA incluido es:"+newPrecio);
    }

    static double getPrecioIva(double precio) {
        double precioIva = precio - precio*0.21;
        return precioIva;
    }
}