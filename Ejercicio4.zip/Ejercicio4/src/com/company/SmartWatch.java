package com.company;

public class SmartWatch extends SmartDevice {

    String malla;

    public SmartWatch(String malla) {
    }
    public SmartWatch(String marca, String color, String RAM, double precio, String malla) {
        super(marca, color, RAM, precio);
        this.malla = malla;
    }

    @Override
    public String toString() {
        return "SmartWatch{" +
                "malla='" + malla + '\'' +
                ", marca='" + marca + '\'' +
                ", color='" + color + '\'' +
                ", RAM='" + RAM + '\'' +
                ", precio=" + precio +
                "} ";
    }
}

