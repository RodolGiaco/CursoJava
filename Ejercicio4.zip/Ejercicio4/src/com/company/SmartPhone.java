package com.company;

public class SmartPhone extends SmartDevice {

    String camara;
    String SD;

    public SmartPhone(){

    }

    public SmartPhone(String marca, String color, String RAM, double precio, String camara, String SD) {
        super(marca, color, RAM, precio);
        this.camara = camara;
        this.SD = SD;
    }

    @Override
    public String toString() {
        return "SmartPhone{" +
                "camara='" + camara + '\'' +
                ", SD='" + SD + '\'' +
                ", marca='" + marca + '\'' +
                ", color='" + color + '\'' +
                ", RAM='" + RAM + '\'' +
                ", precio=" + precio +
                "} ";
    }
}

