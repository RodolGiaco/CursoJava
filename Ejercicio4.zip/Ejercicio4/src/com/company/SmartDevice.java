package com.company;

public class SmartDevice {

    //Atributos
    String marca;
    String color;
    String RAM;
    double precio;
    public SmartDevice(){

    }
    public SmartDevice(String marca, String color, String RAM, double precio) {
        this.marca = marca;
        this.color = color;
        this.RAM = RAM;
        this.precio = precio;
    }

    @Override
    public String toString() {
        return "SmartDevice{" +
                "marca='" + marca + '\'' +
                ", color='" + color + '\'' +
                ", RAM=" + RAM +
                ", precio=" + precio +
                '}';
    }
}
