package com.company;

public class ClaseMain {
    public static void main(String[] args) {

        SmartDevice dispositivo1 = new SmartDevice("Huawei","Negro","8 GByte",12000);
        SmartDevice telefono1 = new SmartPhone("Huawei","Negro","8 GB",12000,"50Mpx","64GB");
        SmartDevice reloj1 = new SmartWatch("Samsung","Rojo","2 GB",50000,"Metalizada");

        System.out.println(dispositivo1);
        System.out.println(telefono1);
        System.out.println(reloj1);


    }
}